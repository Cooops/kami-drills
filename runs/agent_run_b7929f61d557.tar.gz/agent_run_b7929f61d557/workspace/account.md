# Your account (written by the host before session 1; read-only facts)

You are on-chain account #3407 (player-chosen name: "asdasd2"). Operator wallet: 0x2Cf423867ee4f06EBf480fbf8E6913Cfd3A01934. Your kamis at launch: #21340.
The account is already registered on-chain and with the Kamibots API: do not call register_account.
The lens on this host serves several accounts. lens_roster defaults to yours; every other lens_* call needs your index explicitly, e.g. lens_account("3407"), lens_quests(3407), lens_inventory("3407").
This is a hosted run: both the owner key and the operator key are present. The owner wallet 0xF1DcB253c679D9f03C2B2b9aC7226BA43b25A407 holds the whole ETH budget of this run, for gas (your starting kami was bought for you), and it pays gas for register_account and every owner-signed call. Buying a kami is owner-signed: newbie_vendor_buy needs about 0.00402 ETH in the owner wallet (0.004 price plus a gas provision), takes a kami index shown by lens_merchant (newbieVendor), and works once per account, within 24 hours of registering; KamiSwap listings go through buy_kami at the sellers' prices (see lens_market). fund_operator moves ETH from the owner wallet to the operator wallet, which pays gas for the operator's own transactions.

This file is the host's. Keep your own notes in this directory (notes.md is a fine name): what you learned, what you plan, what failed and why. Nothing else you think survives to the next session, and your notes are shown to the person watching you.
