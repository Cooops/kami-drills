# Plan — maximize quest completions
Account #3397 / coopdaloop. Updated 2026-10-15 22:40 UTC.

## Immediate: Quest #20 — Harvesting Data III
- Accepted/incomplete, objective: >720 min (`HARVEST_TIME` 43,200 sec) at Hollow Path #37. Fresh full registry row at block 34508717 shows 33,321 / 43,200 seconds, so 9,879 sec (~2h45m) remain.
- Kami #715 is HARVESTING at #37, HP 103/240, HP rate -7.51/hr (block 34508699; fresh node read at 34508708 also 103). Plan: wake in 130 minutes; then inspect fresh HP and progress. If remaining time is still positive and the node is safe, schedule another short interval. At objective completion, immediately `harvest_stop` to secure progress/rewards. Check `quest_state`/`check_quest_completable` before completing #20.
- Liquidation preview at block 34508708: attackers #15297 threshold 42 and #18165 threshold 38; target HP 103, both currently ineligible. Prior death history confirms #15297 killed kami #715 at 41 HP and #18165 at 36 HP. At present HP loss rate, 130 minutes should leave ~87 HP, still ~45 HP above known highest kill gate. Recheck node thresholds and HP at wake; stop if HP nears 50 or the threshold becomes concerning. Do not leave it harvesting for a long unattended span after quest completion.
- Room 37, MUSU 10,904, stamina 100. Scavenge points #37 are 113/200 (block 34508699); #37 droptable only Wooden Stick (88.89%) / Pine Cone (11.11%). No need to claim before 200.

## Other open quests / limits
- #2006 Community Outreach: >720 minutes at Lost Skeleton #25 DURING MOONSIDE. Kami was killed there by #11820 twice; avoid sending while that threat is present. Current phase MOONSIDE, cycle hour 34; DAYLIGHT in ~4,958 sec at 22:37 UTC, so do not attempt 12-hour Moonside objective now. Check again next cycle.
- #2008 Offering an Apprenticeship: post-acceptance scavenge objectives Pine Cone #1004 x1, Daffodil #1011 x1, Sanguine Shroom #1013 x1, Plastic Bottle #1003 x2. Holdings (Pine Cone 4, Bottle 1) do not count; Hollow Path drops no required item except Pine Cone.
- #3001 Rejecting Fate requires reroll; `gacha_reroll` needs owner wallet and reroll ticket; owner key is unavailable. #3006 What's In a Name? requires 1 Holy Dust #11011 and room 11; none known. #3007 Land Survey requires 500 moves. #3015 Wages of Sin requires burn 5 Obols #1015; 0 held. #3900 Warm Your Hands repeatable but no catalog objective row.

## Account / operations
- Use account label `main` for all game actions; account index 3397 for lens queries. Only kami #715. Current inventory: MUSU 10,904; VIPP 1,295; 13 Sticks, 32 Stone, 1 Plastic Bottle, 4 Pine Cones, 5 Chalkberries, 6 Red Ribbon Gummies, 14 Ice Creams, 8 Neith spell cards. No kami food/onyx/hot quest items.
- Operator ETH 0.001014067154999425; owner ETH 0.000663570855599997, mainnet ETH 0. Owner-signed actions unavailable (host has only operator key). Preserve operator gas.
- Lens daemon LIVE, block lag 1. Harvest state and all quest progress from fresh block reads above.
