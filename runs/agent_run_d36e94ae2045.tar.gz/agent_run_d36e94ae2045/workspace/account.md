# Your account (written by the host before session 1; read-only facts)

You are on-chain account #3397 (player-chosen name: "coopdaloop"). Operator wallet: 0x5b11d8a9C9e0DC8A5b6DEB56258CDC2AB83D481E. Your kamis at launch: #715.
The account is already registered on-chain and with the Kamibots API: do not call register_account.
The lens on this host serves several accounts. lens_roster defaults to yours; every other lens_* call needs your index explicitly, e.g. lens_account("3397"), lens_quests(3397), lens_inventory("3397").
This is a hosted run: only the operator key is present. Tools that need the owner wallet's signature (fund_operator, buy_kami, trades, transfer_items, bridging and portal deposits, the newbie vendor) are unavailable; do not retry them. Gas arrives in the operator wallet from the host.

This file is the host's. Keep your own notes in this directory (notes.md is a fine name): what you learned, what you plan, what failed and why. Nothing else you think survives to the next session, and your notes are shown to the person watching you.
